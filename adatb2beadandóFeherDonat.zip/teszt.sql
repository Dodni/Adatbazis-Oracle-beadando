DROP TABLE addresses;
DROP TABLE phone_numbers;
DROP TABLE emails;
DROP TABLE users;
/

DROP TABLE users;
DROP TABLE emails;
DROP TABLE phone_numbers;
DROP TABLE addresses;
--Mindent megpr�b�lunk els�nek eldobni, hogy nyugodtan l�tretudjunk hozni minden t�bl�t.

CREATE TABLE users(
	id INT primary key,
	user_id INT,
	ph_id INT,
	name VARCHAR(45),
	email VARCHAR(45)	
);

CREATE TABLE phone_numbers(
	ph_id INT primary key,
	phone_number VARCHAR(20)
);--kesz

CREATE TABLE addresses(
	id INT primary key,
	user_id INT,
	street VARCHAR(45),
	street2 VARCHAR(45),
	city VARCHAR(45),
	state VARCHAR(45),
	zip VARCHAR(45)
);--kesz

ALTER TABLE users ADD CONSTRAINT fk_users FOREIGN KEY (ph_id)REFERENCES phone_numbers;
ALTER TABLE users ADD CONSTRAINT fk_users2 FOREIGN KEY(user_id)REFERENCES addresses;

Insert into addresses (id, user_id,street,street2,city,state,zip) values ('1','1','Pet�fi S�ndor utca 1',null,'Kecskem�t','B�cs-Kiskun','6000');
Insert into addresses (id, user_id,street,street2,city,state,zip) values ('2','2','Bagi L�szl� utca 2',null,'Kecskem�t','B�cs-Kiskun','6000');
Insert into addresses (id, user_id,street,street2,city,state,zip) values ('3','3','T�glagy�r utca 3','Polg�r utca 15','Kecskem�t','B�cs-Kiskun','6000');
Insert into addresses (id, user_id,street,street2,city,state,zip) values ('4','4','Maros utca 4',null,'Kecskem�t','B�cs-Kiskun','6000');
Insert into addresses (id, user_id,street,street2,city,state,zip) values ('5','5','F�rd� utca 5',null,'Kecskem�t','B�cs-Kiskun','6000');
Insert into addresses (id, user_id,street,street2,city,state,zip) values ('6','6','T�m�rk�ny Istv�n utca 6',null,'Kecskem�t','B�cs-Kiskun','6000');
Insert into addresses (id, user_id,street,street2,city,state,zip) values ('7','7','Domby Lajos utca 7',null,'Kecskem�t','B�cs-Kiskun','6000');
Insert into addresses (id, user_id,street,street2,city,state,zip) values ('8','8','M�rcius 15. utca 8',null,'Kecskem�t','B�cs-Kiskun','6000');
Insert into addresses (id, user_id,street,street2,city,state,zip) values ('9','9','Ir�nyi utca 9',null,'Kecskem�t','B�cs-Kiskun','6000');
Insert into addresses (id, user_id,street,street2,city,state,zip) values ('10','10','Forradalom utca 10',null,'Kecskem�t','B�cs-Kiskun','6000');
--addresses adattagok hozz�ad�sa

Insert into phone_numbers (ph_id, phone_number) values ('1','0670000001');
Insert into phone_numbers (ph_id, phone_number) values ('2','0670000002');
Insert into phone_numbers (ph_id, phone_number) values ('3','0670000003');
Insert into phone_numbers (ph_id, phone_number) values ('4','0670000004');
Insert into phone_numbers (ph_id, phone_number) values ('5','0670000005');
Insert into phone_numbers (ph_id, phone_number) values ('6','0670000006');
Insert into phone_numbers (ph_id, phone_number) values ('7','0670000007');
Insert into phone_numbers (ph_id, phone_number) values ('8','0670000008');
Insert into phone_numbers (ph_id, phone_number) values ('9','0670000009');
Insert into phone_numbers (ph_id, phone_number) values ('10','0670000010');
--phone_number adattagok hozz�ad�sa

Insert into users (id,user_id,ph_id,name,email) values ('1','1','1','Pistike','pistike@gmail.com');
Insert into users (id,user_id,ph_id,name,email) values ('2','2','2','Lacika','lacika@gmail.com');
Insert into users (id,user_id,ph_id,name,email) values ('3','3','3','Dodika','dodika@gmail.com');
Insert into users (id,user_id,ph_id,name,email) values ('4','4','4','Adrika,'adrika@gmail.com');
Insert into users (id,user_id,ph_id,name,email) values ('5','5','5','Edike','edike@gmail.com');
Insert into users (id,user_id,ph_id,name,email) values ('6','6','6','Robika,'robika@gmail.com');
Insert into users (id,user_id,ph_id,name,email) values ('7','7','7','Vikike','vikike@gmail');
Insert into users (id,user_id,ph_id,name,email) values ('8','8','8','D�rika','d�rika@gmail');
Insert into users (id,user_id,ph_id,name,email) values ('9','9','9','Misike','misike@gmail.com');
Insert into users (id,user_id,ph_id,name,email) values ('10','10','10','Apenka','apenka@gmail.com');
--users adattagok hozz�ad�sa