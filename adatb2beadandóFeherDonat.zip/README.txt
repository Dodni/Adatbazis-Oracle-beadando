Tisztelt Tanár Úr!
adatb2beadandoFeladatokFeherDonat.txt file-ban vannak a megoldott feladatok.
adatb2beadandoFeherDonat.docx file-ban meg egy kis dokumentáció és az adatbázis létrehozásához kellő script. Ez ugyanúgy megtalálható a parancsok.txt file-ban.

Készítette: Fehér Donát